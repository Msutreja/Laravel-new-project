# Laravel-project
i Develop this Project Using Laravel Framework

## Installation

Follow these steps to set up the project locally:

1. **Clone the Repository:**

   ```bash
   git clone https://github.com/Msutreja/Laravel-project.git
   cd your-repo-name

2. **Run Project:**
    when you done download project and locally setup complete
    go to your Terminal
    write this artisan command
    => php artisan migrate
    => php artisan serve

    your project is ready 
